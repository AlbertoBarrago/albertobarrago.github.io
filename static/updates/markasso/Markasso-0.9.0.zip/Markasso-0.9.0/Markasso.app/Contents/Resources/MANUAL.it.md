## Lavagne e file

Sul Mac ogni lavagna è un documento: un file `.markasso` sul tuo disco, nella cartella che preferisci, iCloud Drive compreso. Il formato è lo stesso della web app, quindi lo stesso file si apre in entrambe.

| Azione | Come |
|--------|------|
| Nuova lavagna | **Archivio → Nuovo** (`⌘N`) |
| Apri | **Archivio → Apri…** (`⌘O`), doppio clic sul file nel Finder, trascinalo su una lavagna, oppure **Archivio → Apri recenti** |
| Salva | **Archivio → Salva…** (`⌘S`): la prima volta chiede dove mettere la lavagna |
| Duplica | **Archivio → Duplica** (`⇧⌘S`): una copia modificabile, salvata dove scegli |
| Rinomina o sposta | **Archivio → Rinomina…** e **Archivio → Sposta in…**, oppure il menu della barra del titolo |
| Versioni precedenti | **Archivio → Ripristina → Sfoglia tutte le versioni…** |
| Esporta | **Archivio → Esporta PNG…** (`⇧⌘E`), **Esporta SVG…**, **Esporta HTML embed…** |

### Il salvataggio è automatico

Markasso salva le lavagne mentre lavori, come ogni app per documenti del Mac: una lavagna salvata non perde modifiche quando esci o il Mac si riavvia. Una lavagna mai salvata resta una bozza finché non la salvi o la chiudi; alla chiusura ti chiede se tenerla.

macOS conserva anche le versioni precedenti di ogni lavagna. Apri **Archivio → Ripristina → Sfoglia tutte le versioni…** per vederle affiancate e ripristinarne una, o copiare elementi da una versione vecchia.

### Nel Finder

Seleziona un file `.markasso` e premi Spazio: Quick Look mostra la lavagna intera. Nelle viste a icone e a galleria il Finder mostra un'immagine della lavagna invece di un'icona generica. Entrambe usano il canvas chiaro per una lavagna disegnata con tratti scuri e quello scuro per una disegnata con tratti chiari; quando i tratti non bastano a deciderlo, seguono l'aspetto del Mac.

### Spotlight

Spotlight trova le tue lavagne in base alle parole che contengono: testi ed etichette di forme, icone e connettori, oltre ai nomi dei livelli e delle icone. Cercale in Spotlight o in una finestra del Finder.

### Una finestra, tante lavagne

Ogni lavagna che apri o crei diventa un pannello della finestra in primo piano, così una sola finestra le tiene tutte. Trascina un pannello fuori dalla barra dei pannelli, o scegli **Finestra → Sposta pannello in una nuova finestra**, per dare a una lavagna la sua finestra; **Finestra → Unisci tutte le finestre** le riunisce.

### Il pannello Lavagne

Non serve tenere aperte tutte le lavagne: chiuderne una non fa perdere nulla, e il pannello **Lavagne** la riapre con un clic. Elenca le lavagne aperte ora, poi tutte quelle che hai aperto o modificato, divise per giorno: Oggi, Ieri, gli ultimi giorni, poi per mese. Ognuna ha una miniatura, aggiornata quando la salvi o la chiudi.

- **Nella barra laterale:** la scheda **Lavagne** accanto a **Libreria** (`⌥⌘B`, oppure **Vista → Mostra lavagne**). La lavagna evidenziata è quella di questa finestra.
- **In una finestra:** **Finestra → Finestra Lavagne** (`⇧⌘B`) mostra lo stesso elenco come griglia di miniature grandi.
- Fai clic su una lavagna per aprirla come pannello, o per portarla davanti se è già aperta; con `⌥`-clic si apre in una finestra tutta sua. La × su una lavagna aperta la chiude.
- Scrivi nel campo di ricerca per filtrare per nome o cartella.
- Con il clic destro trovi **Mostra nel Finder**, **Apri in una nuova finestra** e **Rimuovi dall'elenco**, che toglie solo la voce. Una lavagna eliminata o spostata dove Markasso non arriva chiede di essere rimossa.
- **Sposta nel Cestino** (sempre nel menu del clic destro) elimina la lavagna dopo una conferma: una lavagna aperta viene prima chiusa, e il file va nel Cestino, da dove il Finder può ripristinarlo.
- Ogni riga mostra l'orario e la cartella della lavagna; una lavagna aperta indica se ha modifiche non ancora salvate.

### Riprendi da dove avevi lasciato

Se esci con delle lavagne aperte, Markasso le riapre al prossimo avvio, com'erano. Segue l'impostazione di sistema **Chiudi le finestre quando esci da un'app** (Impostazioni di Sistema → Scrivania e Dock): tienila disattivata per avere questo comportamento.

La cronologia degli annullamenti appartiene al documento aperto: sopravvive ai salvataggi, ma non alla chiusura della lavagna o all'uscita dall'app.

### File di versioni più recenti

Una lavagna salvata da una versione più recente di Markasso si apre **in sola lettura**: puoi guardarla, selezionare, cercare ed esportare, ma non modificarla, e Markasso non la sovrascrive mai. Il sottotitolo della finestra dice **Sola lettura**. Usa **Archivio → Duplica** per averne una copia modificabile nel formato attuale.

### Cosa resta sul tuo Mac

Tutto: le lavagne sono file tuoi e non viene caricato niente. Markasso ricorda anche, per tutte le finestre:

- lo stato della Libreria, le sue sezioni e i tuoi elementi recenti
- i pacchetti di icone importati (in `~/Library/Application Support/Markasso/IconPacks`)
- se l'Inspector è visibile e da quale lato, e se la minimappa è visibile

---

## La finestra

Ogni finestra di lavagna ha, da sinistra a destra, la barra laterale con le schede **Lavagne** e **Libreria**, il **canvas** e la barra laterale dell'**Inspector**. **Vista → Posizione inspector** scambia i lati: la barra laterale prende sempre il lato opposto all'Inspector.

- La **toolbar** contiene il pulsante della barra laterale (mostra l'ultima scheda usata), il blocco strumento, gli strumenti, lo strumento forme flowchart (il suo menu sceglie il simbolo) e il pulsante dell'Inspector.
- **Vista → Mostra lavagne** (`⌥⌘B`), **Vista → Mostra libreria** (`I` sul canvas) e **Vista → Mostra inspector** (`⌥⌘I`) aprono e chiudono le barre laterali; ricordano il loro stato.
- La **minimappa** sta nell'angolo in basso a destra del canvas (`M`, oppure **Vista → Mostra minimappa**).
- Il pulsante dello **zoom** nella toolbar mostra il livello di zoom: un clic torna al 100%, il suo menu ingrandisce, riduce o adatta.
- Premi `\` (oppure **Vista → Nascondi interfaccia**) per una vista pulita senza toolbar e Inspector; premilo di nuovo per farli tornare.
- Pannelli delle finestre, schermo intero e Split View funzionano come in ogni app del Mac.
- Con **VoiceOver**, il canvas elenca i suoi elementi, dal più in alto, ognuno chiamato come nella ricerca ("Rettangolo: API"), selezionato o bloccato; attivarne uno lo seleziona. Su una lavagna grande, Trova elementi (`⌘F`) li raggiunge tutti.

### Blocco strumento

Il **pulsante del lucchetto** prima degli strumenti decide cosa succede quando finisci di disegnare:

- **Spento (predefinito):** lo strumento torna a Selezione e il nuovo elemento è selezionato, pronto da modificare nell'Inspector.
- **Acceso:** lo strumento di disegno resta attivo e puoi disegnare subito la forma successiva. Anche nel menu **Strumenti**.

---

## Strumenti

Scegli uno strumento dalla toolbar, dal menu **Strumenti** o con il suo tasto. I tasti degli strumenti funzionano quando il canvas ha il focus e non stai scrivendo.

| Strumento | Tasto | Descrizione |
|-----------|-------|-------------|
| Mano | `H` o tieni premuto `Spazio` | Sposta il canvas |
| Selezione | `V` o `1` | Seleziona, sposta, ridimensiona, ruota gli elementi |
| Rettangolo | `R` o `2` | Disegna rettangoli |
| Rombo | `D` o `3` | Disegna rombi |
| Ellisse | `E` o `4` | Disegna ellissi e cerchi |
| Linea / Freccia | `A`, `L` o `5` | Disegna linee e frecce, collegate alle forme |
| Penna | `P` o `6` | Disegno a mano libera, con la pressione su una tavoletta |
| Testo | `T` o `7` | Aggiungi testo |
| Nota adesiva | `N` | Aggiungi note adesive |
| Forma flowchart | `S` | Disegna l'ultimo simbolo flowchart scelto |
| Gomma | `0` | Cancella gli elementi cliccandoci o trascinandoci sopra |

Premi `Esc` per tornare allo strumento Selezione.

---

## Disegno

### Forme

Fai clic e trascina per disegnare un rettangolo, un'ellisse, un rombo o un simbolo flowchart. Tieni premuto `Shift` per mantenere le proporzioni (quadrato, cerchio). Fai doppio clic su una forma per scriverci dentro un'etichetta.

### Linee e frecce

Fai clic e trascina dall'inizio alla fine. Tieni premuto `Shift` per agganciare l'angolo a passi di 45°. Passa sopra una forma per vederne evidenziato il bordo: inizia o finisci lì per **collegare** la linea, che poi segue la forma quando si sposta. Quando un'estremità è vicina a una forma compaiono quattro **porte**: rilascia su una porta per fissare lì l'estremità, in un altro punto del bordo per lasciarla scorrere.

Trascina la maniglia centrale di una linea per curvarla. Nell'Inspector, **Percorso → A gomito** disegna connettori ortogonali, e **Punta iniziale** e **Punta finale** scelgono le punte di freccia. Fai doppio clic su un connettore per dargli un'etichetta.

### Penna

Trascina per disegnare; il tratto viene ammorbidito quando rilasci, e la penna resta attiva per il tratto successivo.

### Gomma

Fai clic o trascina sugli elementi per cancellarli: va via prima l'elemento più in alto sotto il puntatore, quelli bloccati vengono saltati. L'elemento che sta per essere cancellato è evidenziato e una breve scia segue il puntatore. Un intero trascinamento è un solo passo di annullamento.

### Immagini

Scegli **Inserisci → Immagine…**, incolla un'immagine (`⌘V`) o trascina un file immagine sul canvas. L'immagine entra nella lavagna stessa, quindi il file la mostra ovunque; se è più grande di 600 punti viene ridotta, mantenendo le proporzioni. Le foto in formati che il web non mostra (HEIC, TIFF) vengono salvate come PNG.

### Modelli

**Inserisci → Modelli** aggiunge un diagramma pronto al centro della vista, raggruppato: un flowchart, una mappa mentale, un'analisi SWOT o un diagramma di sequenza, nei colori del tema corrente. Separa il gruppo (`⇧⌘G`) per modificare i pezzi uno per uno.

### Testo e note adesive

Fai clic per posizionare il testo e scrivi. `Invio` va a capo; `Shift+Invio`, `Esc` o un clic fuori confermano. Fai doppio clic su un testo per modificarlo. In **modalità codice** (Inspector) il testo è un blocco monospaziato e `Tab` indenta.

Una nota adesiva (`N`) mantiene la sua larghezza, va a capo da sola e si allunga quando serve. Una nota vuota viene rimossa.

---

## Libreria

La **Libreria** (`I`, **Vista → Mostra libreria** o la scheda Libreria della barra laterale; **Inserisci → Importa pacchetto di icone (ZIP)…** la apre sull'importazione) è una barra laterale con ricerca che contiene tutto ciò che puoi inserire. La prima volta parte chiusa, poi ricorda il suo stato.

- **Fai clic** su un elemento per inserirlo al centro della vista, selezionato, con lo stile corrente, oppure **trascinalo** sul canvas per metterlo dove lo rilasci.
- Il campo di **ricerca** filtra tutte le sezioni insieme; gli elementi usati di recente compaiono per primi.
- Le sezioni si chiudono; Kubernetes e i pacchetti importati partono chiusi.

### Forme e icone

- **Forme flowchart:** Inizio / Fine, Dati (I/O), Documento, Database, Processo predefinito, Preparazione, Input manuale, Ritardo.
- **Icone:** le icone di architettura di Markasso (server, database, cache, coda, API, utente e altre). Seguono i colori di bordo e riempimento e hanno un'etichetta modificabile.
- **Kubernetes:** il set ufficiale di icone Kubernetes, incluso con licenza Apache-2.0.

### Importare le icone AWS, Azure e Google Cloud

I fornitori cloud permettono le loro icone nei diagrammi ma non la loro redistribuzione, quindi lo ZIP ufficiale lo scarichi tu:

- **AWS:** [AWS Architecture Icons](https://aws.amazon.com/architecture/icons/)
- **Azure:** [Azure architecture icons](https://learn.microsoft.com/azure/architecture/icons/)
- **Google Cloud:** [Google Cloud icons](https://cloud.google.com/icons)

1. In fondo alla Libreria, fai clic su **Importa pacchetto di icone (ZIP)** e scegli il file.
2. Il pacchetto compare come nuova sezione, con il nome del fornitore e diviso per le sue categorie.
3. Per rimuoverlo, fai clic sul pulsante del cestino accanto al nome.

I pacchetti importati restano su questo Mac. Una lavagna incorpora le icone che usa, quindi il file le mostra su qualsiasi Mac e sul web.

---

## Selezione

- **Fai clic** su un elemento per selezionarlo; **Shift-clic** lo aggiunge o lo toglie.
- **Trascina** sul canvas vuoto per una selezione a riquadro. **Seleziona tutto** è `⌘A`.
- **Trascina** una selezione per spostarla. **Opzione-trascina** o **Shift-trascina** lascia l'originale e sposta una copia.
- Trascina le **maniglie** per ridimensionare (tieni `Shift` su un angolo per mantenere le proporzioni) o la maniglia rotonda per ruotare.
- I **tasti freccia** spostano di 1 punto, di 10 con `Shift`.
- `Cancella` o `Backspace` rimuove la selezione; gli elementi bloccati restano.
- **Trascina la selezione fuori dalla finestra** per portarla altrove: nel Finder diventa un file PNG o SVG (il formato scelto nelle Impostazioni; tieni premuto `⌥` mentre la selezione esce dalla lavagna per l'altro), in Keynote, Pages o Mail un'immagine, su un'altra lavagna una copia degli elementi. La lavagna da cui la trascini resta com'era.

---

## Disponi

Il menu **Disponi** e le righe dell'Inspector organizzano la selezione.

| Azione | Come |
|--------|------|
| Porta in primo piano | `⇧⌘]` |
| Porta avanti, manda indietro | `⌘]`, `⌘[`: di un passo |
| Porta in fondo | `⇧⌘[` |
| Allinea | **Disponi → Allinea**, oppure la riga di allineamento dell'Inspector (due o più elementi) |
| Raggruppa | `⌘G` |
| Separa | `⇧⌘G` |
| Blocca o sblocca | `⇧⌘L` |
| Copia e incolla stile | `⌥⌘C` copia lo stile dell'elemento selezionato: fai clic su un elemento per applicarlo (pennello formato), oppure seleziona degli elementi e premi `⌥⌘V` (**Disponi → Incolla stile**), anche su un'altra lavagna |
| Duplica | `⌘D`: una copia a 20 punti di distanza |

Fai clic su un membro di un gruppo per selezionare tutto il gruppo, di nuovo per selezionare solo lui, `Esc` per tornare al gruppo. Gli elementi bloccati restano visibili e selezionabili ma non si possono spostare, ridimensionare, cancellare o collegare; la toolbar mostra un pulsante per sbloccarli quando la selezione ne contiene.

---

## Inspector

L'**Inspector** (`⌥⌘I`) mostra lo stile della selezione, o del prossimo elemento quando è attivo uno strumento di disegno. Elenca solo ciò che si applica:

- Colore di **riempimento** e di **bordo**, con preimpostazioni, sfumature, selettore colore e campo esadecimale
- **Spessore** e **stile del tratto** (continuo, tratteggiato, punteggiato)
- **Estremità**, **punte di freccia** e **percorso** per linee e frecce
- **Imprecisione**, da netta a disegnata a mano, e **bordi** (vivi o arrotondati)
- **Opacità**
- **Famiglia** del carattere, **dimensione** e **stile** del testo, e **modalità codice**, per i testi
- La **forma** flowchart, che cambia il simbolo sul posto

Ogni modifica è un passo di annullamento; trascinare il cursore dell'opacità è un solo passo per tutto il trascinamento.

---

## Modifica e cronologia

| Azione | Scorciatoia |
|--------|-------------|
| Annulla | `⌘Z` |
| Ripristina | `⇧⌘Z` |
| Copia | `⌘C` |
| Taglia | `⌘X` |
| Incolla | `⌘V` |
| Duplica | `⌘D` |
| Elimina | `Cancella` / `Backspace` |
| Seleziona tutto | `⌘A` |
| Svuota la lavagna | **Composizione → Cancella tela…** (chiede conferma; un annulla riporta tutto) |

Gli elementi copiati si incollano in qualsiasi lavagna, qui o nella web app: copia sul Mac e incolla nel browser, o il contrario. Ogni incolla finisce 20 punti più in là del precedente. Taglia lascia sulla lavagna gli elementi bloccati. Mentre scrivi dentro un elemento, questi comandi agiscono sul suo testo.

---

## Navigazione

| Azione | Come |
|--------|------|
| Spostati | Scorri con due dita, tieni `Spazio` e trascina, oppure lo strumento Mano |
| Zoom | Pizzica, oppure scorri tenendo `⌘` o `Control` |
| Ingrandisci, riduci | `⌘=`, `⌘-` (anche `Control` con `+` o `-`) |
| Dimensioni reali | `⌘0`, oppure `Shift+0` per tornare anche all'origine |
| Adatta al contenuto | `F`, `⌘9` oppure **Vista → Adatta al contenuto** |
| Griglia | `G` la mostra o la nasconde; **Vista → Griglia** sceglie anche punti, linee o carta millimetrata |
| Minimappa | `M` oppure **Vista → Mostra minimappa** |

La **minimappa** mostra tutta la lavagna e l'area visibile. Fai clic o trascina al suo interno per spostare la vista in quel punto. Si nasconde da sola quando il canvas è più stretto di 700 punti.

---

## Riquadro comandi

Premi `⌘K` (oppure **Vista → Riquadro comandi…**) e scrivi: strumenti, forme flowchart, icone e azioni vengono trovati mentre scrivi, i migliori per primi.

- `↑` / `↓` oppure `Tab` / `Shift+Tab` scorrono i risultati, `Invio` ne esegue uno.
- `Esc`, di nuovo `⌘K` o un clic fuori lo chiudono.
- Tra le azioni ci sono annulla e ripristina, zoom e adatta, griglia, seleziona tutto, elimina, duplica, esporta, salva e **Cancella tela** (chiede conferma).

---

## Ricerca elementi

Premi `⌘F` (oppure **Composizione → Trova elementi…**) per cercare gli elementi per tipo, testo, etichetta o colore (per esempio `#e03131`). I più recenti vengono per primi e il numero compare accanto al campo.

- `↑` / `↓` oppure `Tab` scorrono i risultati; gli elementi selezionati sono segnati.
- `Invio` seleziona l'elemento e ci porta la vista.
- `Esc` o `⌘F` chiudono la ricerca.

---

## Impostazioni

Apri **Markasso → Impostazioni…** (`⌘,`).

- **Tema:** Sistema (segue macOS e cambia all'istante), Chiaro o Scuro. Quando il canvas diventa chiaro o scuro, il colore di default dei tratti passa a quello che risalta su di esso.
- **Sfondo del canvas:** sei tinte per il canvas dell'aspetto in uso. Chiaro e scuro ricordano ognuno la sua scelta, che compare quando quell'aspetto è attivo. Lo usano anche gli export.
- **Mostra minimappa** e **Mostra suggerimenti**.
- **Formato del trascinamento:** PNG o SVG, il file che diventa una selezione trascinata dalla lavagna nel Finder.
- **Lingua:** Markasso usa la lingua di macOS. Per usarne un'altra solo per Markasso, sceglila in Impostazioni di Sistema → Generali → Lingua e Zona → Applicazioni (il pulsante la apre).

Le lavagne appaiono uguali con ogni tema: i colori degli elementi fanno parte della lavagna.

---

## Esportare

**Archivio → Esporta PNG…**, **Esporta SVG…** ed **Esporta HTML embed…** salvano tutta la lavagna nell'aspetto corrente. I file SVG sono identici all'export della web app per la stessa lavagna.

- **Archivio → Condividi immagine…** invia la lavagna come PNG ad AirDrop, Mail, Messaggi e alle altre destinazioni di condivisione. **Archivio → Condividi** (di macOS) invia il file `.markasso` stesso.
- **Archivio → Stampa…** (`⌘P`) stampa tutta la lavagna su una pagina, adattata e centrata, in orizzontale se è più larga che alta, su carta bianca. Nel pannello di stampa, **PDF → Salva come PDF** la mantiene nitida a qualsiasi ingrandimento. **Archivio → Formato di stampa…** (`⇧⌘P`) sceglie la carta.
- **Servizi → Nuova lavagna Markasso dalla selezione**: seleziona del testo in qualsiasi app, poi scegli questo Servizio dal menu dell'app (o dal menu del clic destro). Markasso apre una nuova lavagna con un testo per riga.

---

## Aiuto

- **Aiuto → Guida di Markasso:** questa guida. Il campo di ricerca filtra le sezioni.
- **Aiuto → Scorciatoie da tastiera**, oppure `?` sul canvas: tutte le scorciatoie in un colpo d'occhio. `Esc` o `?` le chiudono.
- **Aiuto → Markasso su GitHub:** la pagina del progetto. La versione è in **Markasso → Informazioni su Markasso**.
- **Suggerimenti:** quando scegli uno strumento, in fondo al canvas compare per qualche secondo un breve aiuto. Dopo un po' di inattività un suggerimento propone una scorciatoia che non hai ancora usato; ogni suggerimento si ritira quando usi la sua scorciatoia o dopo tre volte.

---

## Markasso sul web

L'app per Mac e [la web app](https://markasso.it) leggono e scrivono gli stessi file `.markasso`: salva una lavagna sul web e aprila qui, o il contrario. L'app per Mac aggiunge ciò che il Mac fa bene, come i file nel Finder, il salvataggio automatico, le versioni e la riapertura delle lavagne all'avvio.

Non ancora nell'app per Mac: link di condivisione, sessioni live e il collegamento MCP per gli agenti AI. Questa guida viene aggiornata man mano che arrivano.
