## Boards and Files

On the Mac every board is a document: a `.markasso` file on your disk, in any folder you like, iCloud Drive included. The format is the web app's own, so the same file opens in both.

| Action | How |
|--------|-----|
| New board | **File → New** (`⌘N`) |
| New tab | **File → New Tab** (`⌘T`) or the **+** at the end of the tab bar: a new board in a tab of the window in front |
| From a template | **File → New from Template…** (`⌥⌘N`) shows the templates in the Boards window (**‹ Boards** or `Esc` goes back): flowchart, mind map, SWOT, sequence, architecture, retrospective or kanban, in the colors of the appearance in use. Everything on it can be changed |
| Your own templates | **File → Save as Template…** keeps a copy of the board, under the name you give it, among **Your Templates** in **New from Template…**. Control-click one of them there to rename it or move it to the Trash |
| Open | **File → Open…** (`⌘O`), double-click the file in Finder, drag it onto a board, or **File → Open Recent** |
| Save | **File → Save…** (`⌘S`): the first time it asks where to put the board |
| Duplicate | **File → Duplicate** (`⇧⌘S`): an editable copy, saved where you choose |
| Rename or move | **File → Rename…** and **File → Move To…**, or the title bar's menu |
| Earlier versions | **File → Revert To → Browse All Versions…** |
| Export | **File → Export PNG…** (`⇧⌘E`), **Export SVG…**, **Export HTML embed…** |

### Saving is automatic

Markasso saves your boards as you work, like any Mac document app: a board you saved never loses changes when you quit or the Mac restarts. A board you never saved stays as a draft until you save or close it; closing asks whether to keep it.

macOS also keeps earlier versions of each board. Open **File → Revert To → Browse All Versions…** to see them side by side and restore one, or copy elements from an old version.

### In Finder

Select a `.markasso` file and press Space: Quick Look shows the whole board. In icon and gallery views Finder shows a picture of the board instead of a generic icon. Both use the light canvas for a board drawn with dark strokes and the dark canvas for one drawn with light strokes; when the strokes don't tell, they follow the Mac's appearance.

### Spotlight

Spotlight finds your boards by the words on them: texts and the labels of shapes, icons and connectors, plus layer and icon names. Search for any of them in Spotlight or in a Finder window.

### One window, many boards

Every board you open or create becomes a tab of the front window, so one window holds them all. Drag a tab out of the tab bar, or choose **Window → Move Tab to New Window**, to give a board its own window; **Window → Merge All Windows** gathers them again.

### The Boards window

You don't need to keep every board open: closing one loses nothing, and the **Boards** window brings it back in one click. It lists the boards open now, then every board you opened or edited, by day: Today, Yesterday, the last few days, then by month. Each has a thumbnail, refreshed when you save or close it.

- **Window → Boards Window** (`⇧⌘B`) opens it: the boards as a grid of large thumbnails.
- **At launch:** when no board is open (at launch, or clicking the Dock icon with no window), the Boards window opens as the start screen, with **Blank Board**, **From a Template** and **From a Link** (**From the Cloud** with cloud boards) at the top. **From a Template** slides the templates in over your boards, in the same window. Choosing one opens the new board and the start screen goes away. **Settings → At Launch** brings back the blank board instead.
- Click a board to open it as a tab, or to bring it forward if it is already open; `⌥`-click opens it in a window of its own.
- Type in the search field to filter by name or folder.
- Right-click for **Show in Finder**, **Open in New Window** and **Remove from List** (**Close** on an open board), which only forgets the board. A board that was deleted or moved out of reach asks to be removed.
- **Move to Trash** (also in the right-click menu) deletes the board after asking: an open board is closed first, and the file goes to the Trash, where Finder can put it back.
- Each board shows the time and the folder of the board; an open board shows whether it has edits not saved yet.

### Picking up where you left off

When you quit with boards open, Markasso reopens them the next time it starts, as they were. This follows the system setting **Close windows when quitting an app** (System Settings → Desktop & Dock): turn it off to keep this behaviour.

Undo history belongs to the open document: it survives saves, but not closing the board or quitting the app.

### Files from newer versions

A board saved by a newer version of Markasso opens **read-only**: you can look at it, select, search and export, but not change it, and Markasso never overwrites it. The window's subtitle says **Read-Only**. Use **File → Duplicate** to get an editable copy in the current format.

### What stays on your Mac

Everything: boards are files you own, and nothing is uploaded. Markasso also remembers, for all windows:

- the Library's open state, its sections and your recent items
- the icon packs you imported (in `~/Library/Application Support/Markasso/IconPacks`)
- whether the Inspector is shown and on which side, and whether the minimap is shown

---

## The Window

Each board window has, from left to right, the **Library** sidebar, the **canvas** and the **Inspector** sidebar. **View → Inspector Position** swaps the sides: the Library always takes the side opposite the Inspector.

- The **toolbar** holds the Library button, the tool lock, the tools, the flowchart shape tool (its menu picks the symbol) and the Inspector button.
- **View → Show Library** (`I` on the canvas) and **View → Show Inspector** (`⌥⌘I`) open and close the sidebars; they remember their state.
- The **minimap** sits in the bottom-right corner of the canvas (`M`, or **View → Show Minimap**).
- The toolbar's **zoom** button shows the zoom level: click it for 100%, or open its menu to zoom in, zoom out or fit.
- Press `\` (or **View → Hide Interface**) for a clean view without the toolbar and the Inspector; press it again to bring them back.
- Window tabs, full screen and Split View work as in any Mac app.
- With **VoiceOver**, the canvas lists its elements, topmost first, each named like a search result ("Rectangle: API"), selected or locked; activating one selects it. On a large board, Find Elements (`⌘F`) reaches any of them.

### Tool Lock

The **lock button** before the tools controls what happens after you finish drawing:

- **Off (default):** the tool returns to Select and the new element is selected, ready to style in the Inspector.
- **On:** the drawing tool stays active so you can draw the next shape right away. Also in the **Tools** menu.

---

## Tools

Pick a tool from the toolbar, the **Tools** menu or its key. Tool keys work while the canvas has the focus and you are not typing.

| Tool | Key | Description |
|------|-----|-------------|
| Hand | `H` or hold `Space` | Pan the canvas |
| Select | `V` or `1` | Select, move, resize, rotate elements |
| Rectangle | `R` or `2` | Draw rectangles |
| Rhombus | `D` or `3` | Draw diamonds |
| Ellipse | `E` or `4` | Draw ellipses and circles |
| Line / Arrow | `A`, `L` or `5` | Draw lines and arrows, connected to shapes |
| Pen | `P` or `6` | Freehand drawing, with pressure on a tablet |
| Text | `T` or `7` | Add text |
| Sticky note | `N` | Add sticky notes |
| Flowchart shape | `S` | Draw the flowchart symbol picked last |
| Eraser | `0` | Erase elements by clicking or dragging over them |

Press `Escape` to go back to the Select tool.

---

## Drawing

### Shapes

Click and drag to draw a rectangle, ellipse, rhombus or flowchart symbol. Hold `Shift` to keep the proportions (square, circle). Double-click a shape to type a label inside it.

### Lines and Arrows

Click and drag from the start to the end. Hold `Shift` to snap the angle to 45° steps. Hover a shape to see its border highlighted: start or end there to **connect** the line, which then follows the shape when it moves. While a connector end is near a shape, four **ports** appear: drop on a port to pin the end there, anywhere else on the border to let it slide.

Drag the midpoint handle of a line to bend it into a curve. In the Inspector, **Routing → Elbow** draws orthogonal connectors, and **Start head** and **End head** choose the arrowheads. Double-click a connector to give it a label.

### Pen

Drag to draw; the stroke is smoothed when you release, and the pen stays active for the next stroke.

### Eraser

Click or drag over elements to delete them: the topmost element under the pointer goes first, locked elements are skipped. The element about to be erased is highlighted and a short trail follows the pointer. A whole drag is one undo step.

### Images

Choose **Insert → Image…**, paste an image (`⌘V`) or drag an image file onto the canvas. The image goes into the board itself, so the file shows it everywhere; one larger than 600 points is scaled down, keeping its proportions. Photos in formats the web cannot show (HEIC, TIFF) are stored as PNG.

### Presets

**Insert → Presets** adds a ready-made diagram at the center of the view, grouped: a flowchart, a mind map, a SWOT analysis or a sequence diagram, in the colors of the current theme. Ungroup it (`⇧⌘G`) to edit the pieces one by one.

### Text and Sticky Notes

Click to place text and type. `Return` starts a new line; `Shift+Return`, `Escape` or a click outside commits. Double-click a text to edit it. In **code mode** (Inspector) the text is a monospaced block and `Tab` indents.

A sticky note (`N`) keeps its width, wraps its text and grows taller when needed. An empty note is removed.

---

## Library

The **Library** (`I`, **View → Show Library**, or the toolbar's Library button; **Insert → Import icon pack (ZIP)…** opens it on the import) is a searchable sidebar with everything you can insert. It opens closed the first time, then remembers.

- **Click** an item to insert it at the center of the view, selected, with the current style, or **drag** it onto the canvas to place it where you drop it.
- The **search** field filters all sections at once; recently used items are listed first.
- Sections fold; the Kubernetes and imported packs start folded.

### Shapes and Icons

- **Flowchart shapes:** Start / End, Data (I/O), Document, Database, Predefined process, Preparation, Manual input, Delay.
- **Icons:** Markasso's architecture icons (server, database, cache, queue, API, user and more). They follow the stroke and fill colors and carry an editable label.
- **Kubernetes:** the official Kubernetes icon set, bundled under the Apache-2.0 license.

### Importing AWS, Azure and Google Cloud Icons

Cloud vendors allow their icons in diagrams but not their redistribution, so you download the official ZIP yourself:

- **AWS:** [AWS Architecture Icons](https://aws.amazon.com/architecture/icons/)
- **Azure:** [Azure architecture icons](https://learn.microsoft.com/azure/architecture/icons/)
- **Google Cloud:** [Google Cloud icons](https://cloud.google.com/icons)

1. At the bottom of the Library, click **Import icon pack (ZIP)** and choose the file.
2. The pack appears as a new section, named after the vendor and grouped by its categories.
3. To remove it, click the trash button next to its name.

Imported packs stay on this Mac. A board embeds the icons it uses, so the file shows them on any Mac and on the web.

---

## Selection

- **Click** an element to select it; **Shift-click** adds or removes it.
- **Drag** on empty canvas for a marquee selection. **Select All** is `⌘A`.
- **Drag** a selection to move it. **Option-drag** or **Shift-drag** leaves the original and moves a copy.
- Drag the **handles** to resize (hold `Shift` on a corner to keep the proportions) or the round handle to rotate.
- The **arrow keys** nudge by 1 point, 10 with `Shift`.
- `Delete` or `Backspace` removes the selection; locked elements stay.
- **Drag the selection out of the window** to take it elsewhere: dropped in Finder it becomes a PNG or SVG file (the format chosen in Settings; hold `⌥` as the selection leaves the board for the other one), in Keynote, Pages or Mail a picture, on another board a copy of the elements. The board you dragged from stays as it was.

---

## Arrange

The **Arrange** menu and the Inspector's rows organize the selection.

| Action | How |
|--------|-----|
| Bring to front | `⇧⌘]` |
| Bring forward, send backward | `⌘]`, `⌘[`: one step |
| Send to back | `⇧⌘[` |
| Align | **Arrange → Align**, or the Inspector's alignment row (two or more elements) |
| Group | `⌘G` |
| Ungroup | `⇧⌘G` |
| Lock or unlock | `⇧⌘L` |
| Copy and paste style | `⌥⌘C` copies the selected element's style: click an element to apply it (format painter), or select elements and press `⌥⌘V` (**Arrange → Paste Style**), also on another board |
| Duplicate | `⌘D`: a copy 20 points away |

Click a group member to select the whole group, click it again to select it alone, `Escape` to go back to the group. Locked elements stay visible and selectable but cannot be moved, resized, deleted or connected; the toolbar shows an unlock button while the selection holds one.

---

## Inspector

The **Inspector** (`⌥⌘I`) shows the style of the selection, or of the next element when a drawing tool is active. Like on the web, it opens by itself when you select something or pick a drawing tool, and closes again when neither is left if it was the one that opened; opened by hand, it stays. A sidebar opening or closing never moves the drawing: it just covers what is under it. **Settings → Appearance → Style Controls** can put a **floating bar** next to the selection instead: colors, stroke width and style, arrowheads and routing, text options, duplicate, bring to front and delete, with **More Styles…** to open or close the full inspector. It only lists what applies:

- **Fill** and **stroke** color, with presets, shades, a color picker and a hex field
- **Stroke width** and **stroke style** (solid, dashed, dotted)
- **Line cap**, **arrowheads** and **routing** for lines and arrows
- **Roughness**, from crisp to hand-drawn, and **corners** (sharp or rounded)
- **Opacity**
- **Font**, **size** and text **style**, and **code mode**, for text
- The flowchart **shape**, which switches the symbol in place

Every change is one undo step; dragging the opacity slider is one step for the whole drag.

---

## Editing and History

| Action | Shortcut |
|--------|----------|
| Undo | `⌘Z` |
| Redo | `⇧⌘Z` |
| Copy | `⌘C` |
| Cut | `⌘X` |
| Paste | `⌘V` |
| Duplicate | `⌘D` |
| Delete | `Delete` / `Backspace` |
| Select all | `⌘A` |
| Clear the board | **Edit → Clear canvas…** (it asks first; one undo brings everything back) |

Copied elements paste into any board, here or in the web app: copy on the Mac and paste in the browser, or the other way round. Each paste lands 20 points further than the previous one. Cut leaves locked elements on the board. While you are typing inside an element, these commands work on its text.

---

## Navigation

| Action | How |
|--------|-----|
| Pan | Scroll with two fingers, hold `Space` and drag, or the Hand tool |
| Zoom | Pinch, or scroll while holding `⌘` or `Control` |
| Zoom in, zoom out | `⌘=`, `⌘-` (also `Control` with `+` or `-`) |
| Actual size | `⌘0`, or `Shift+0` to also return to the origin |
| Fit to content | `F`, `⌘9` or **View → Zoom to Fit** |
| Grid | `G` shows or hides it; **View → Grid** also picks dots, lines or graph paper |
| Minimap | `M` or **View → Show Minimap** |

The **minimap** shows the whole board and the visible area. Click or drag in it to move the view there. It hides itself when the canvas is narrower than 700 points.

---

## Command Palette

Press `⌘K` (or **View → Command Palette…**) and type: tools, flowchart shapes, icons and actions are matched as you type, the best first.

- `↑` / `↓` or `Tab` / `Shift+Tab` move through the results, `Return` runs one.
- `Escape`, `⌘K` again or a click outside closes it.
- Actions include undo and redo, zoom and fit, grid, select all, delete, duplicate, export, save and **Clear canvas** (it asks first).

---

## Element Search

Press `⌘F` (or **Edit → Find Elements…**) to find elements by type, text, label or color (for example `#e03131`). The newest come first and the count shows next to the field.

- `↑` / `↓` or `Tab` move through the results; selected elements are marked.
- `Return` selects the element and zooms to it.
- `Escape` or `⌘F` closes the search.

---

## Assistant

The assistant is a preview. It works on the board in the window: it answers questions about it and prepares changes you review before they reach the board. Set up its provider first in **Settings → Assistant**.

Press `⌘J` (or **View → Assistant**, the ✨ toolbar button or the Command Palette) to show it in the inspector's place; **Style** and **Assistant** at the top switch between the two. `⌘J` again hides it. Don't want it? Turn off **Show the Assistant** in **Settings → Assistant**: it leaves the inspector, the menu, the toolbar and the palette, and its settings stay.

- **Context:** **Selection** sends the selected elements with their connections and the elements they connect to (those are read, not changed); **Whole Board** sends every visible element. With nothing selected the whole board goes. The counts show what will be sent. Hidden elements are never sent, and locked ones are read but never changed.
- **Ask or describe a change** in the field and press `Return`. While it works, **Cancel** (or `Escape`) stops it and nothing it would still do is kept.
- **A proposal** collects the changes, with how many elements it adds, changes and removes. Nothing reaches the board yet: follow up in the field to refine it ("also show failed attempts"), then **Apply** puts it on the board as one step (`⌘Z` takes it all back), or **Discard** drops it.
- If the board changes while a proposal is open, **Apply** is disabled: the next request starts over from the board as it is.
- After an error the proposal stays: **Try Again** sends the request again.
- The conversation lasts while the board is open and is shared by its windows; ✎ at the top starts a new one. Closing the board stops a request in flight.

Requests go straight from your Mac to the provider you chose. A local server keeps the board on your Mac.

---

## Settings

Open **Markasso → Settings…** (`⌘,`). The tabs at the top split it by topic; the last one you used opens next time.

**General**

- **At Launch:** the start screen (your boards, plus new ones blank, from a template or from a link) or a new blank board, as before.
- **Drag Out Format:** PNG or SVG, the file a selection dragged from the board into Finder becomes.
- **Language:** Markasso uses the language of macOS. To use another one for Markasso alone, choose it in System Settings → General → Language & Region → Applications (the button opens it).

**Appearance**

- **Theme:** System (follows macOS and switches live), Light or Dark. When the canvas turns light or dark, the default stroke color changes to the one that stands out on it.
- **Canvas background:** six tints for the canvas of the appearance in use. Light and dark each keep their own choice, shown when that appearance is active. Exports use it too.
- **Style Controls:** the inspector in the sidebar, or a floating bar next to the selection (see Inspector).
- **Show minimap** and **Show tips**.

Boards look the same in every theme: element colors are part of the board.

**Cloud** and **Assistant** are the last two tabs.

- **Cloud:** the cloud licence key (see Cloud Boards below).
- **Assistant:** the **Provider** the integrated assistant will use, each with its own model, endpoint and key, kept when you switch: **Anthropic** (Claude Opus 5.5 by default, or another model from the menu or typed in, and an optional endpoint for a company gateway that speaks Anthropic's API), **OpenAI** (or a gateway that speaks its API), or a **Local Server** such as Ollama or LM Studio (`http://localhost:11434` by default, no key needed). The models the server offers appear in the menu next to the model by themselves, for a local server right away and for OpenAI once its key is saved; ↻ loads them again. The model must support tools: an embedding model or one without tool support is refused by the server. **Test Connection** sends one small request to check them. Requests go straight from your Mac to the provider and are billed to the key's account; a chat subscription does not include API access, and third-party apps may not sign in with a Claude account. At work, ask your administrator for a key from the company's Anthropic or OpenAI workspace (or the address of the company's gateway): usage then goes to the company. A local server keeps the board on your Mac. Keys stay in your Mac's Keychain.

---

## Export

**File → Export PNG…**, **Export SVG…** and **Export HTML embed…** save the whole board in the current appearance. SVG files are identical to the web app's export of the same board.

- **File → Copy Share Link** puts a markasso.it link on the clipboard: anyone with it can view a copy of the board, on the web or in the app, for 90 days. Without a connection, or for a very large board, the link carries the whole board itself: it is long, but it never expires.
- **File → Open Link…** (`⇧⌘O`) opens a markasso.it share link as a new board. Save it to keep it. Links that a browser or another app hands to Markasso (`markasso://`) open the same way.
- **File → Share Image…** sends the board as a PNG to AirDrop, Mail, Messages and the other share destinations. **File → Share** (from macOS) sends the `.markasso` file itself.
- **File → Print…** (`⌘P`) prints the whole board on one page, fitted and centered, landscape when it is wider than tall, on white paper. In the print panel, **PDF → Save as PDF** keeps it sharp at any zoom. **File → Page Setup…** (`⇧⌘P`) picks the paper.
- **Services → New Markasso Board from Selection**: select text in any app, then choose this Service from the app menu (or the right-click menu). Markasso opens a new board with one text per line.

---

## Help

- **Help → Markasso Guide:** this guide. The search field filters the sections.
- **Help → Keyboard Shortcuts**, or `?` on the canvas: every shortcut at a glance. `Escape` or `?` closes it.
- **Help → Markasso on GitHub:** the project's page. The version is in **Markasso → About Markasso**.
- **Hints and tips:** choosing a tool shows a short hint at the bottom of the canvas for a few seconds. After a while without activity a tip suggests a shortcut you have not used yet; each tip retires once you use its shortcut or after three showings.

---

## Markasso on the Web

The Mac app and [the web app](https://markasso.it) read and write the same `.markasso` files: save a board on the web and open it here, or the other way round. The Mac app adds what a Mac does well, like files in Finder, automatic saving, versions and reopening your boards on launch.

Share links work here too (**File → Open Link…** and **Copy Share Link**). Not in the Mac app yet: live sessions and the MCP connection for AI agents. This guide is updated as they arrive.

### Cloud Boards

A cloud board lives on markasso.it and stays in sync between the Mac app and the browser, with no account: its links are the keys.

- **File → Cloud Board → Save to Cloud…** puts the board in the cloud (it appears once a licence is in Settings; until then the menu has **Cloud Licence…** and **Subscription and Pricing** in its place; with a licence, **Cloud Licence…** has a green check; a stored key markasso.it no longer accepts, expired or revoked, counts as none until you replace it). From then on every change goes there a moment after you stop editing, and when you close the window. Cloud boards are public by link: the **read link** lets anyone view the board, the **edit link** lets anyone change it. Keep the edit link private.
- **Copy Read Link**, **Copy Edit Link** and **Open on the Web** are in the same menu. The edit link is kept in your Mac's Keychain, never in the file.
- The button at the right of the title bar shows the state: synced, saving, offline, read-only or a problem. Click it for the details and the links: each link says what it grants, and its **Copy** button turns into **Copied** once the link is on the clipboard. Offline, changes stay on your Mac and go to the cloud when the connection returns.
- **Changes made elsewhere** (on the web or another Mac) arrive when you come back to the window, and every 30 seconds while it is in front, as one step you can undo. Markasso waits while you are dragging or typing; if you changed the board here too, it asks which version to keep.
- **Opening a cloud board:** **File → Open Link…**, or click a link (the web's "Open in the Mac app" button too). With the read link the board opens read-only and follows the cloud version; **File → Duplicate** makes an editable copy. Opening its edit link later makes it editable. If your Mac already keeps a different edit link for that board, it asks before replacing it.
- **Changed in two places:** if the board changed in the cloud while you were editing here, Markasso asks which version to keep. **Keep Mine** replaces the cloud version, **Take Theirs** replaces yours (**Edit → Undo** brings it back), **Save a Copy** keeps yours as a new board. Nothing is overwritten until you choose.
- **License:** creating and saving cloud boards needs a Markasso license key; reading them and share links stay free. Paste the key in **Markasso → Settings… → Cloud** (**Buy a License…** is next to it: Markasso Cloud is a subscription, monthly or yearly). After paying, the key arrives by email and stays in your customer portal (the link is in that email). markasso.it checks it when you save it (a key it refuses is not kept; when it cannot be reached the key is kept and checked on the next save), and it stays in your Mac's Keychain; boards waiting for a license start saving as soon as you enter it.
- **File → Cloud Board → Stop Syncing…** unlinks the file; the board stays in the cloud. A duplicate is never linked, and a file linked on another Mac starts syncing once you open its edit link here.
- With Handoff, a cloud board you are looking at shows up on your other devices: their browser opens its read link.
