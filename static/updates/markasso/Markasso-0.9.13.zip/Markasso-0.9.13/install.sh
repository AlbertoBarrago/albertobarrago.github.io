#!/bin/zsh
# Installs a Markasso build from the shell. Shipped inside the release zip; needs nothing from the repository.
#
#   zsh install.sh                    installs the Markasso.app next to this script
#   zsh install.sh Markasso-...zip    installs from a zip
#   zsh install.sh /path/Markasso.app installs a given app
#
# What it does: quits a running Markasso (its own dialogs ask about unsaved drafts), copies the app to /Applications
# (or ~/Applications without write access there), removes the quarantine flag, registers it with Launch Services
# (the .markasso document type, Quick Look and Spotlight) and opens it.
#
# Removing the quarantine flag is how an app signed for development and not notarized is allowed to run: it skips
# the Gatekeeper check for this app only. Do it only for builds you got from Markasso's releases.
# Graphical alternative: open the app, then System Settings > Privacy & Security > "Open Anyway".
# Later updates come through Sparkle (Markasso > Check for Updates…) and need none of this.
set -euo pipefail

HERE="${0:A:h}"
SOURCE="${1:-$HERE/Markasso.app}"
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

if [[ "$SOURCE" == *.zip ]]; then
  ditto -x -k "$SOURCE" "$WORK"
  SOURCE=$(find "$WORK" -maxdepth 3 -name 'Markasso.app' -type d | head -n 1)
fi
if [[ ! -d "$SOURCE" || "${SOURCE:t}" != "Markasso.app" ]]; then
  echo "Markasso.app not found (looked for: ${1:-$HERE/Markasso.app})." >&2
  exit 66
fi
APP_NAME="${SOURCE:t}"
BUNDLE_ID=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$SOURCE/Contents/Info.plist")

# A running copy would keep the old binary in use.
running() { pgrep -f "/$APP_NAME/Contents/MacOS/Markasso" >/dev/null; }
if running; then
  echo "Quitting the running ${APP_NAME%.app} (answer its dialogs if it asks about drafts)..."
  osascript -e "tell application id \"$BUNDLE_ID\" to quit" >/dev/null 2>&1 || true
  for _ in {1..60}; do
    running || break
    sleep 1
  done
  if running; then
    echo "${APP_NAME%.app} is still running. Quit it (Cmd-Q) and run this script again." >&2
    exit 75
  fi
fi

DEST_DIR=/Applications
if [[ ! -w "$DEST_DIR" ]]; then
  DEST_DIR="$HOME/Applications"
  mkdir -p "$DEST_DIR"
fi
DEST="$DEST_DIR/$APP_NAME"

echo "Installing into $DEST_DIR..."
rm -rf "$DEST"
ditto "$SOURCE" "$DEST"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true

if ! codesign --verify --deep --strict "$DEST" 2>/dev/null; then
  echo "The app signature is not valid: the download may be damaged. Download it again." >&2
  exit 65
fi
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$DEST"

VERSION=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$DEST/Contents/Info.plist" 2>/dev/null || echo "?")
echo "${APP_NAME%.app} $VERSION installed. Opening..."
open "$DEST"
